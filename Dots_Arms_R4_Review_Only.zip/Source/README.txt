Historical FreeCAD Python generators for hands and capture tool only.
These files construct geometry; they do not control motors.
Requires FreeCAD Python modules (FreeCAD, Part) and standard Python libraries.
Create cad and qa directories beside the scripts before running. The supplied
Linux module path may need adjustment for your FreeCAD installation.
Reproduction was not rerun for this public packaging. The full R4 arms/workstation
matching generator is not included; an older arm generator does not reproduce it.
Generated files overwrite their specific outputs in those cad and qa directories.
