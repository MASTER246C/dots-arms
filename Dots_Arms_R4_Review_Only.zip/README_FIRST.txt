PATCH ROBOTICS R4 — WORK-IN-PROGRESS SNAPSHOT
Historical design review snapshot dated 2026-10-02 UTC. Public packaging 2026-10-13.
Read LICENSE before use. Prior written build permission from Christopher Kalkowski
and an agreed opportunity for him to observe are required before physical builds.
Contact: https://chriskalkowski.com/contact/
Permission is not engineering or safety approval.

OPEN FIRST: CAD/Patch_R4_WIP_Full_Assembly.FCStd in FreeCAD.
A STEP copy is supplied for other CAD programs. Separate arm/head, paired-hand and capture-tool assemblies are included. The capture tool is an alternative to a hand, not attached on top of a hand.

The assembled viewing model contains 394 individually named objects. Its two bases are posed at 60 and120 degrees to present the hands over the workbench. The screen-head is placed at the left side in the assembled viewing pose for visibility; the standalone layout retains its prior screen position. Component descriptions cover these objects plus the26-object capture tool. Views are actual CAD renders, not photographs or a physical prototype. Repeated left/right parts use matching labels.

DESIGN TARGET
30 lb per arm/hand at three-foot reach remains the target, with ordinary jobs around5–10 lb. The two-hand oven-dish example does not lower that target. A higher combined capacity must still account for asymmetric loading and coordinated grip; no60lb lift rating is established.

WHAT THIS SNAPSHOT CONTAINS
- Metal-frame tendon-hand candidates, thumb joints, linear-drive envelopes, wrist-camera carriers
- Floor-supported, detachable dual-arm layout with shoulder/elbow screw drives and rotary wrist joints
- Screen-head, keyboard and cooled print-plate workbench references
- Alternative underside-support capture tool
- Six views around the assembly and a labeled contact sheet
- A part-by-part explanation keyed to CAD object names

CURRENT CHECKS AND LIMITS
All394 assembled CAD object shapes passed the geometric validity check. Three sampled single-arm poses for the latest18-inch shoulder-drive candidate cleared classified external solid intersections; internal rod/barrel and rod/eye envelope overlaps were excluded explicitly. These samples do not establish complete swept motion, cross-arm clearance, attached-tool clearance, cable routing or physical tolerances. The hand neutral screen is clear; restricted thumb tests are partial motion checks.

This is not fabrication-ready and has no physically tested30lb rating. Exact mounting fasteners and joints, revised structural masses/stresses, complete wiring/safety circuit, power-loss load retention, heat/duty-cycle behavior and physical commissioning remain unfinished. Some parts are component envelopes or joined-stock layout candidates. A valid CAD solid is not a validated load path. Do not build or energize from this snapshot as though it were released engineering drawings.

The larger shoulder geometry uses a listed18-inch PA-17-POT candidate. Its estimated full shoulder sweep is about56 seconds at catalogue full-load speed, with25% duty cycle; this is a slow heavy-load candidate, not an agile production robot. Product revision, availability and final component selection remain subject to verification. The drawing geometry and explanation guide are current work; they are not a purchase list.

Power-tool handling is not permission or qualification to operate energized cutting/drilling equipment. The dish example is treated as cooled. Screens, cameras and an AI planner are not substitutes for independent safety hardware.
